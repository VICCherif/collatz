"""
Utilizando el lenguaje o los lenguajes de programación que usted prefiera, escriba el código de un web
service que para la entrada de un número natural entregue un arreglo JSON con la secuencia de collatz
asociada a ese número.

>>> index()
secuencia
"""

from flask import Flask,jsonify

app = Flask(__name__)

@app.route('/',methods=['GET'])
def index():

    def collatz(num):
        secuen= [num]
        while num > 1:
            if num % 2 == 0:
                num //=2
            else:
                num = num * 3 + 1
            secuen.append(num)
                
        return secuen

    secuencia = collatz(11)
    testList = [
  11, 
  34, 
  17, 
  52, 
  26, 
  13, 
  40, 
  20, 
  10, 
  5, 
  16, 
  8, 
  4, 
  2, 
  1
]
    if secuencia == testList:
        # genera un reporte
        reporte=open("reporte_positivo.txt","w")
        reporte.write("Los resultados de la Prueba de habilidad estan correctos :D ")
        reporte.close()
    else:
        reporte=open("reporte_negativo.txt","w")
        reporte.write("Los resultados de la Prueba de habilidad estan ERRONEOS :(")
        reporte.close()
    return jsonify(secuencia)
if __name__=="__main__":
    app.run(debug=True)

import doctest
doctest.testmod()
